# TP1A - Projet DiceForge - Pour Axopen le 1/10/20


<h3> Code pour lancer N partie : mvn exec:java -Dexec.args="-p N" </h3>
<h3> Code pour lancer une partie : mvn install | mvn exec:java. Pour les tests, mvn test.</h3>


Dans le cadre d'un projet de dévelopement en master, nous devions réaliser le jeu de plateau DiceForge en Java, que j'ai ensuite retravaillé pour cet entretient. 


Regles du jeu : C'est un jeu de dice crafting dans lequel des dieux sont à la recherche d'une nouvelle divinité. Ils décident donc d'organiser un tournoi pour choisir l'élu, le hero qui sera digne de siéger avec eux. 
Pour cela, les heros devrons s'attirer les faveurs des dieux en lançant des dés aux faces amovibles pour récolter des ressources et  des points de victoires. 
Les héros devront donc, réaliser les épreuves avant leurs adversaires et explorer les multiples stratégies pour remporter le plus de points de vitoire.

J'ai décidé de vous partager ce projet car il necessite un bon niveau de developpement en Java, et l'utilisation de nombreuses technologies, comme des sockets, une IA faible, des tests unitaires et un environnement client-serveur. 

Autres details importants :
Le code est entierement commenté et chaque fonctionnalité est testable. 
Vous trouverez aussi dans ce dossier un diagramme de classe du projet. 

